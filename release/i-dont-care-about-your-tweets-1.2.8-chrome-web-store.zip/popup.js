"use strict";
(() => {
  // src/shared/browser/get-ui-language.ts
  function getUiLanguage() {
    try {
      const locale = globalThis.chrome?.i18n?.getUILanguage?.();
      if (locale) {
        return locale;
      }
    } catch {
    }
    return globalThis.navigator?.language ?? "en";
  }

  // src/shared/browser/is-rtl-locale.ts
  var RTL_LOCALE_PREFIXES = ["ar", "fa", "he"];
  function isRtlLocale(locale) {
    const normalized = locale.toLowerCase();
    return RTL_LOCALE_PREFIXES.some(
      (prefix) => normalized === prefix || normalized.startsWith(`${prefix}-`)
    );
  }

  // src/shared/browser/set-document-locale-attributes.ts
  function setDocumentLocaleAttributes(doc = document, locale = getUiLanguage()) {
    const dir = isRtlLocale(locale) ? "rtl" : "ltr";
    doc.documentElement.lang = locale;
    doc.documentElement.dir = dir;
    return { lang: locale, dir };
  }

  // src/_locales/en/messages.json
  var messages_default = {
    extensionName: {
      message: "I Don'T Care About Your Tweets"
    },
    extensionDescription: {
      message: "Adds Block, Mute, and Not Interested buttons to each X.com post."
    },
    actionBlock: {
      message: "Block"
    },
    actionBlockTitle: {
      message: "Block the author of this post"
    },
    actionMute: {
      message: "Mute"
    },
    actionMuteTitle: {
      message: "Mute the author of this post"
    },
    actionDismiss: {
      message: "Not interested"
    },
    actionDismissTitle: {
      message: "Tell X that you are not interested in this post"
    },
    popupPageTitle: {
      message: "I Don't Care About Your Tweets"
    },
    popupHeading: {
      message: "Button kit"
    },
    popupSubtitle: {
      message: "Choose the icon set shown on each post."
    },
    popupReset: {
      message: "Reset"
    },
    popupPreviewAriaLabel: {
      message: "Button kit preview"
    },
    popupKitListAriaLabel: {
      message: "Available button kits"
    },
    kitClassicName: {
      message: "Classic"
    },
    kitClassicDescription: {
      message: "The original button set."
    },
    kitMinimalName: {
      message: "Minimal"
    },
    kitMinimalDescription: {
      message: "Thin, quiet lines for a lighter timeline."
    },
    kitBoldName: {
      message: "Bold"
    },
    kitBoldDescription: {
      message: "Chunkier outlines with stronger visibility."
    },
    kitSharpName: {
      message: "Sharp"
    },
    kitSharpDescription: {
      message: "Angular symbols with a more technical feel."
    },
    kitSoftName: {
      message: "Soft"
    },
    kitSoftDescription: {
      message: "Rounded, friendly shapes with smooth curves."
    },
    dismissFeedbackThankYou: {
      message: "thanks. x will use this to improve your timeline"
    },
    dismissFeedbackUndo: {
      message: "undo"
    },
    popupThemeLight: {
      message: "Day"
    },
    popupThemeDark: {
      message: "Night"
    },
    popupThemeToggleAriaLabel: {
      message: "Toggle popup theme"
    }
  };

  // src/shared/browser/getMessage.ts
  var FALLBACK_MESSAGES = Object.fromEntries(
    Object.entries(messages_default).map(([key, entry]) => [key, entry.message])
  );
  function getMessage(key) {
    try {
      const translated = globalThis.chrome?.i18n?.getMessage(key);
      if (translated) {
        return translated;
      }
    } catch {
      return FALLBACK_MESSAGES[key] ?? key;
    }
    return FALLBACK_MESSAGES[key] ?? key;
  }

  // src/popup/internal/elements.ts
  var kitList = document.querySelector('[data-role="kit-list"]');
  var popupHeading = document.querySelector('[data-role="popup-heading"]');
  var popupSubtitle = document.querySelector('[data-role="popup-subtitle"]');
  var previewBar = document.querySelector('[data-role="preview-bar"]');
  var previewSection = document.querySelector('[data-role="preview"]');
  var resetButton = document.querySelector('[data-action="reset"]');
  var themeToggleButton = document.querySelector('[data-action="toggle-theme"]');

  // src/popup/internal/applyPopupCopy.ts
  function applyPopupCopy() {
    document.title = getMessage("popupPageTitle");
    if (popupHeading) {
      popupHeading.textContent = getMessage("popupHeading");
    }
    if (popupSubtitle) {
      popupSubtitle.textContent = getMessage("popupSubtitle");
    }
    if (resetButton) {
      resetButton.textContent = getMessage("popupReset");
    }
    previewSection?.setAttribute("aria-label", getMessage("popupPreviewAriaLabel"));
    kitList?.setAttribute("aria-label", getMessage("popupKitListAriaLabel"));
  }

  // src/shared/button-kits.ts
  var BUTTON_KIT_STORAGE_KEY = "idcaytButtonKit";
  var DEFAULT_BUTTON_KIT_ID = "classic";
  var BUTTON_KITS = [
    {
      id: "classic",
      nameKey: "kitClassicName",
      descriptionKey: "kitClassicDescription",
      icons: {
        block: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.5 5.5 18.5 18.5M12 3.75a8.25 8.25 0 1 0 0 16.5 8.25 8.25 0 0 0 0-16.5Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"/></svg>',
        dismiss: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 12h15m-4.5-4.5 4.5 4.5-4.5 4.5" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"/></svg>',
        mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.75 14.25h3.5l4.75 3.75V6l-4.75 3.75h-3.5ZM16 9.25l4 5.5M20 9.25l-4 5.5" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"/></svg>'
      }
    },
    {
      id: "minimal",
      nameKey: "kitMinimalName",
      descriptionKey: "kitMinimalDescription",
      icons: {
        block: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.75 6.75 17.25 17.25M12 4.75a7.25 7.25 0 1 0 0 14.5 7.25 7.25 0 0 0 0-14.5Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.45"/></svg>',
        dismiss: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 12h11.5M14 8.5l3.5 3.5-3.5 3.5" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.45"/></svg>',
        mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 14h2.75L13 17.25V6.75L8.75 10H6ZM16.25 10l3 4M19.25 10l-3 4" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.45"/></svg>'
      }
    },
    {
      id: "bold",
      nameKey: "kitBoldName",
      descriptionKey: "kitBoldDescription",
      icons: {
        block: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.25 5.25 18.75 18.75M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.35"/></svg>',
        dismiss: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.25 12h15.25M14.5 7.25 19.5 12l-5 4.75" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.35"/></svg>',
        mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 14.5h3.75l5.25 4.25V5.25L8.25 9.5H4.5ZM16.25 8.75l4 6.5M20.25 8.75l-4 6.5" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.35"/></svg>'
      }
    },
    {
      id: "sharp",
      nameKey: "kitSharpName",
      descriptionKey: "kitSharpDescription",
      icons: {
        block: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5h10l2 2v10l-2 2H7l-2-2V7l2-2ZM6.5 6.5l11 11" fill="none" stroke="currentColor" stroke-linecap="square" stroke-linejoin="miter" stroke-width="1.8"/></svg>',
        dismiss: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.75 12h13.5M14.25 7.5 19 12l-4.75 4.5M4.75 7.5h4.5M4.75 16.5h4.5" fill="none" stroke="currentColor" stroke-linecap="square" stroke-linejoin="miter" stroke-width="1.8"/></svg>',
        mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 14.25h3.5l4.5 3.5V6.25l-4.5 3.5H5ZM16 9l4 6M20 9l-4 6" fill="none" stroke="currentColor" stroke-linecap="square" stroke-linejoin="miter" stroke-width="1.8"/></svg>'
      }
    },
    {
      id: "soft",
      nameKey: "kitSoftName",
      descriptionKey: "kitSoftDescription",
      icons: {
        block: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.2 6.2 17.8 17.8M12 4.25c4.28 0 7.75 3.47 7.75 7.75S16.28 19.75 12 19.75 4.25 16.28 4.25 12 7.72 4.25 12 4.25Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75"/></svg>',
        dismiss: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.25 12h12.5M14.25 8.25 18 12l-3.75 3.75M6.5 8.75c1.35-1.2 3.1-1.8 5.25-1.8" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75"/></svg>',
        mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.25 14.25h3.25l4.75 3.75V6L8.5 9.75H5.25ZM16.15 9.5c1.1 1.35 1.1 3.65 0 5M19 8.25c1.75 2.1 1.75 5.4 0 7.5" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75"/></svg>'
      }
    }
  ];
  var BUTTON_KIT_IDS = new Set(BUTTON_KITS.map((kit) => kit.id));
  var BUTTON_KIT_BY_ID = Object.fromEntries(BUTTON_KITS.map((kit) => [kit.id, kit]));
  function isButtonKitId(value) {
    return typeof value === "string" && BUTTON_KIT_IDS.has(value);
  }
  function normalizeButtonKitId(value) {
    return isButtonKitId(value) ? value : DEFAULT_BUTTON_KIT_ID;
  }
  function getButtonKit(value) {
    return BUTTON_KIT_BY_ID[normalizeButtonKitId(value)];
  }

  // src/popup/internal/actions.ts
  var ACTIONS = ["block", "mute", "dismiss"];

  // src/popup/internal/actionMessageKeys.ts
  var ACTION_MESSAGE_KEYS = {
    block: "actionBlock",
    dismiss: "actionDismiss",
    mute: "actionMute"
  };

  // src/popup/internal/createPreviewButton.ts
  function createPreviewButton(action, kit) {
    const button = document.createElement("button");
    const label = getMessage(ACTION_MESSAGE_KEYS[action]);
    button.type = "button";
    button.className = "preview-action-button";
    button.dataset.previewAction = action;
    button.innerHTML = kit.icons[action];
    button.title = label;
    button.setAttribute("aria-label", label);
    return button;
  }

  // src/popup/internal/applyKitToPreview.ts
  function applyKitToPreview(kit) {
    if (!previewBar) {
      return;
    }
    previewBar.dataset.kitId = kit.id;
    previewBar.replaceChildren(...ACTIONS.map((action) => createPreviewButton(action, kit)));
  }

  // src/popup/internal/setSelectedKit.ts
  function setSelectedKit(kitId) {
    applyKitToPreview(getButtonKit(kitId));
    const kitButtons = Array.from(kitList?.querySelectorAll("[data-kit-id]") ?? []);
    for (const button of kitButtons) {
      const selected = button.dataset.kitId === kitId;
      button.setAttribute("aria-pressed", selected ? "true" : "false");
    }
  }

  // src/popup/internal/getChromeStorageArea.ts
  function getChromeStorageArea() {
    return globalThis.chrome?.storage?.local ?? null;
  }

  // src/popup/internal/writeStoredKitId.ts
  function writeStoredKitId(kitId) {
    const storageArea = getChromeStorageArea();
    if (!storageArea) {
      return Promise.resolve();
    }
    return new Promise((resolve) => {
      try {
        storageArea.set({ [BUTTON_KIT_STORAGE_KEY]: kitId }, resolve);
      } catch {
        resolve();
      }
    });
  }

  // src/popup/internal/selectKit.ts
  async function selectKit(kitId) {
    setSelectedKit(kitId);
    await writeStoredKitId(kitId);
  }

  // src/popup/internal/bindResetButton.ts
  function bindResetButton() {
    resetButton?.addEventListener("click", () => {
      void selectKit(DEFAULT_BUTTON_KIT_ID);
    });
  }

  // src/popup/internal/getNextPopupTheme.ts
  function getNextPopupTheme(theme) {
    return theme === "dark" ? "light" : "dark";
  }

  // src/popup/internal/isPopupTheme.ts
  var POPUP_THEMES = /* @__PURE__ */ new Set(["light", "dark"]);
  function isPopupTheme(value) {
    return typeof value === "string" && POPUP_THEMES.has(value);
  }

  // src/popup/internal/popupTheme.ts
  var DEFAULT_POPUP_THEME = "dark";
  var POPUP_THEME_STORAGE_KEY = "idcaytPopupTheme";

  // src/popup/internal/normalizePopupTheme.ts
  function normalizePopupTheme(value) {
    return isPopupTheme(value) ? value : DEFAULT_POPUP_THEME;
  }

  // src/popup/internal/themeIconMarkup.ts
  var THEME_ICON_MARKUP = {
    dark: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.25 14.3A7.85 7.85 0 0 1 9.7 3.75 8.25 8.25 0 1 0 20.25 14.3Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.9"/></svg>',
    light: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5.25V3.5M12 20.5v-1.75M18.75 12h1.75M3.5 12h1.75M16.77 7.23l1.24-1.24M5.99 18.01l1.24-1.24M16.77 16.77l1.24 1.24M5.99 5.99l1.24 1.24M12 8a4 4 0 1 1 0 8 4 4 0 0 1 0-8Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.9"/></svg>'
  };

  // src/popup/internal/setThemeButtonState.ts
  function setThemeButtonState(theme) {
    const nextTheme = getNextPopupTheme(theme);
    const labelKey = nextTheme === "dark" ? "popupThemeDark" : "popupThemeLight";
    const label = getMessage(labelKey);
    if (themeToggleButton) {
      themeToggleButton.innerHTML = THEME_ICON_MARKUP[nextTheme];
    }
    themeToggleButton?.setAttribute("aria-pressed", theme === "dark" ? "true" : "false");
    themeToggleButton?.setAttribute("aria-label", getMessage("popupThemeToggleAriaLabel"));
    if (themeToggleButton) {
      themeToggleButton.title = label;
    }
  }

  // src/popup/internal/applyPopupTheme.ts
  function applyPopupTheme(theme) {
    document.body.dataset.theme = theme;
    setThemeButtonState(theme);
  }

  // src/popup/internal/writeStoredPopupTheme.ts
  function writeStoredPopupTheme(theme) {
    const storageArea = getChromeStorageArea();
    if (!storageArea) {
      return Promise.resolve();
    }
    return new Promise((resolve) => {
      try {
        storageArea.set({ [POPUP_THEME_STORAGE_KEY]: theme }, resolve);
      } catch {
        resolve();
      }
    });
  }

  // src/popup/internal/selectPopupTheme.ts
  async function selectPopupTheme(theme) {
    applyPopupTheme(theme);
    await writeStoredPopupTheme(theme);
  }

  // src/popup/internal/togglePopupTheme.ts
  async function togglePopupTheme() {
    const currentTheme = normalizePopupTheme(document.body.dataset.theme);
    await selectPopupTheme(getNextPopupTheme(currentTheme));
  }

  // src/popup/internal/bindThemeToggleButton.ts
  function bindThemeToggleButton() {
    themeToggleButton?.addEventListener("click", () => {
      void togglePopupTheme();
    });
  }

  // src/popup/internal/readStoredPopupTheme.ts
  function readStoredPopupTheme() {
    const storageArea = getChromeStorageArea();
    if (!storageArea) {
      return Promise.resolve(DEFAULT_POPUP_THEME);
    }
    return new Promise((resolve) => {
      try {
        storageArea.get({ [POPUP_THEME_STORAGE_KEY]: DEFAULT_POPUP_THEME }, (items) => {
          resolve(normalizePopupTheme(items[POPUP_THEME_STORAGE_KEY]));
        });
      } catch {
        resolve(DEFAULT_POPUP_THEME);
      }
    });
  }

  // src/popup/internal/initializePopupTheme.ts
  function initializePopupTheme() {
    applyPopupTheme(DEFAULT_POPUP_THEME);
    void readStoredPopupTheme().then(applyPopupTheme);
  }

  // src/popup/internal/readStoredKitId.ts
  function readStoredKitId() {
    const storageArea = getChromeStorageArea();
    if (!storageArea) {
      return Promise.resolve(DEFAULT_BUTTON_KIT_ID);
    }
    return new Promise((resolve) => {
      try {
        storageArea.get({ [BUTTON_KIT_STORAGE_KEY]: DEFAULT_BUTTON_KIT_ID }, (items) => {
          resolve(normalizeButtonKitId(items[BUTTON_KIT_STORAGE_KEY]));
        });
      } catch {
        resolve(DEFAULT_BUTTON_KIT_ID);
      }
    });
  }

  // src/popup/internal/initializeSelectedKit.ts
  function initializeSelectedKit() {
    void readStoredKitId().then(setSelectedKit);
  }

  // src/popup/internal/createKitIconPreview.ts
  function createKitIconPreview(kit) {
    const preview = document.createElement("span");
    preview.className = "kit-icon-preview";
    preview.setAttribute("aria-hidden", "true");
    for (const action of ACTIONS) {
      const icon = document.createElement("span");
      icon.className = "kit-icon";
      icon.innerHTML = kit.icons[action];
      preview.append(icon);
    }
    return preview;
  }

  // src/popup/internal/createKitButton.ts
  function createKitButton(kit) {
    const button = document.createElement("button");
    const text = document.createElement("span");
    const name = document.createElement("span");
    const description = document.createElement("span");
    button.type = "button";
    button.className = "kit-option";
    button.dataset.kitId = kit.id;
    button.setAttribute("aria-pressed", "false");
    text.className = "kit-copy";
    name.className = "kit-name";
    name.textContent = getMessage(kit.nameKey);
    description.className = "kit-description";
    description.textContent = getMessage(kit.descriptionKey);
    text.append(name, description);
    button.append(createKitIconPreview(kit), text);
    button.addEventListener("click", () => void selectKit(kit.id));
    return button;
  }

  // src/popup/internal/renderKitOptions.ts
  function renderKitOptions() {
    kitList?.replaceChildren(...BUTTON_KITS.map(createKitButton));
  }

  // src/popup/internal/initializePopup.ts
  function initializePopup() {
    setDocumentLocaleAttributes();
    applyPopupCopy();
    renderKitOptions();
    bindResetButton();
    bindThemeToggleButton();
    initializePopupTheme();
    initializeSelectedKit();
  }

  // src/popup/index.ts
  initializePopup();
})();
