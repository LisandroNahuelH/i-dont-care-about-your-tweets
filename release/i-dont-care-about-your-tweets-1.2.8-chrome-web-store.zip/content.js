"use strict";
(() => {
  // src/shared/button-kits.ts
  var BUTTON_KIT_STORAGE_KEY = "idcaytButtonKit";
  var DEFAULT_BUTTON_KIT_ID = "classic";
  var BUTTON_KITS = [
    {
      id: "classic",
      nameKey: "kitClassicName",
      descriptionKey: "kitClassicDescription",
      icons: {
        block: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.5 5.5 18.5 18.5M12 3.75a8.25 8.25 0 1 0 0 16.5 8.25 8.25 0 0 0 0-16.5Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"/></svg>',
        dismiss: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 12h15m-4.5-4.5 4.5 4.5-4.5 4.5" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"/></svg>',
        mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.75 14.25h3.5l4.75 3.75V6l-4.75 3.75h-3.5ZM16 9.25l4 5.5M20 9.25l-4 5.5" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"/></svg>'
      }
    },
    {
      id: "minimal",
      nameKey: "kitMinimalName",
      descriptionKey: "kitMinimalDescription",
      icons: {
        block: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.75 6.75 17.25 17.25M12 4.75a7.25 7.25 0 1 0 0 14.5 7.25 7.25 0 0 0 0-14.5Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.45"/></svg>',
        dismiss: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 12h11.5M14 8.5l3.5 3.5-3.5 3.5" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.45"/></svg>',
        mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 14h2.75L13 17.25V6.75L8.75 10H6ZM16.25 10l3 4M19.25 10l-3 4" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.45"/></svg>'
      }
    },
    {
      id: "bold",
      nameKey: "kitBoldName",
      descriptionKey: "kitBoldDescription",
      icons: {
        block: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.25 5.25 18.75 18.75M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.35"/></svg>',
        dismiss: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.25 12h15.25M14.5 7.25 19.5 12l-5 4.75" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.35"/></svg>',
        mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 14.5h3.75l5.25 4.25V5.25L8.25 9.5H4.5ZM16.25 8.75l4 6.5M20.25 8.75l-4 6.5" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.35"/></svg>'
      }
    },
    {
      id: "sharp",
      nameKey: "kitSharpName",
      descriptionKey: "kitSharpDescription",
      icons: {
        block: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5h10l2 2v10l-2 2H7l-2-2V7l2-2ZM6.5 6.5l11 11" fill="none" stroke="currentColor" stroke-linecap="square" stroke-linejoin="miter" stroke-width="1.8"/></svg>',
        dismiss: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.75 12h13.5M14.25 7.5 19 12l-4.75 4.5M4.75 7.5h4.5M4.75 16.5h4.5" fill="none" stroke="currentColor" stroke-linecap="square" stroke-linejoin="miter" stroke-width="1.8"/></svg>',
        mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 14.25h3.5l4.5 3.5V6.25l-4.5 3.5H5ZM16 9l4 6M20 9l-4 6" fill="none" stroke="currentColor" stroke-linecap="square" stroke-linejoin="miter" stroke-width="1.8"/></svg>'
      }
    },
    {
      id: "soft",
      nameKey: "kitSoftName",
      descriptionKey: "kitSoftDescription",
      icons: {
        block: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.2 6.2 17.8 17.8M12 4.25c4.28 0 7.75 3.47 7.75 7.75S16.28 19.75 12 19.75 4.25 16.28 4.25 12 7.72 4.25 12 4.25Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75"/></svg>',
        dismiss: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.25 12h12.5M14.25 8.25 18 12l-3.75 3.75M6.5 8.75c1.35-1.2 3.1-1.8 5.25-1.8" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75"/></svg>',
        mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.25 14.25h3.25l4.75 3.75V6L8.5 9.75H5.25ZM16.15 9.5c1.1 1.35 1.1 3.65 0 5M19 8.25c1.75 2.1 1.75 5.4 0 7.5" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75"/></svg>'
      }
    }
  ];
  var BUTTON_KIT_IDS = new Set(BUTTON_KITS.map((kit) => kit.id));
  var BUTTON_KIT_BY_ID = Object.fromEntries(BUTTON_KITS.map((kit) => [kit.id, kit]));
  function isButtonKitId(value) {
    return typeof value === "string" && BUTTON_KIT_IDS.has(value);
  }
  function normalizeButtonKitId(value) {
    return isButtonKitId(value) ? value : DEFAULT_BUTTON_KIT_ID;
  }
  function getButtonKit(value) {
    return BUTTON_KIT_BY_ID[normalizeButtonKitId(value)];
  }

  // src/features/post-actions/config/actionKinds.ts
  var ACTION_KINDS = ["block", "mute", "dismiss"];
  function isActionKind(value) {
    return typeof value === "string" && ACTION_KINDS.includes(value);
  }

  // src/features/post-actions/config/buttonKitPreference.ts
  var currentButtonKit = getButtonKit(DEFAULT_BUTTON_KIT_ID);
  var isListeningForButtonKitChanges = false;
  function getChromeStorageArea() {
    return globalThis.chrome?.storage?.local ?? null;
  }
  function readStoredButtonKitId() {
    const storageArea = getChromeStorageArea();
    if (!storageArea) {
      return Promise.resolve(DEFAULT_BUTTON_KIT_ID);
    }
    return new Promise((resolve) => {
      try {
        storageArea.get({ [BUTTON_KIT_STORAGE_KEY]: DEFAULT_BUTTON_KIT_ID }, (items) => {
          resolve(items[BUTTON_KIT_STORAGE_KEY]);
        });
      } catch {
        resolve(DEFAULT_BUTTON_KIT_ID);
      }
    });
  }
  function applyButtonKitPreference(value) {
    currentButtonKit = getButtonKit(value);
    updateExistingActionButtonIcons();
  }
  function onButtonKitStorageChanged(changes, areaName) {
    if (areaName !== "local") {
      return;
    }
    const kitChange = changes[BUTTON_KIT_STORAGE_KEY];
    if (kitChange) {
      applyButtonKitPreference(kitChange.newValue);
    }
  }
  function getActionIconMarkup(action) {
    return currentButtonKit.icons[action];
  }
  function updateExistingActionButtonIcons() {
    const buttons = Array.from(
      document.querySelectorAll(".idcayt-action-button[data-idcayt-action]")
    );
    for (const button of buttons) {
      const action = button.dataset.idcaytAction;
      if (isActionKind(action)) {
        button.innerHTML = getActionIconMarkup(action);
      }
    }
  }
  function initializeButtonKitPreference() {
    applyButtonKitPreference(DEFAULT_BUTTON_KIT_ID);
    if (!isListeningForButtonKitChanges) {
      try {
        globalThis.chrome?.storage?.onChanged?.addListener(onButtonKitStorageChanged);
        isListeningForButtonKitChanges = true;
      } catch {
      }
    }
    void readStoredButtonKitId().then(applyButtonKitPreference);
  }

  // src/features/post-actions/config/elementSelectors.ts
  var ACTION_BAR_HOST_SELECTOR = '[data-testid="User-Name"] time';
  var ACTION_BAR_SELECTOR = '[data-idcayt-bar="true"]';
  var CONFIRMATION_BUTTON_SELECTORS = [
    'button[data-testid="confirmationSheetConfirm"]',
    'div[data-testid="confirmationSheet"] button',
    '[role="dialog"] button'
  ];
  var MENU_ROOT_SELECTORS = [
    'div[data-testid="Dropdown"]',
    'div[role="menu"]'
  ];
  var MORE_BUTTON_SELECTORS = [
    'button[data-testid="caret"]',
    'div[data-testid="caret"][role="button"]',
    'button[aria-haspopup="menu"]',
    'div[aria-haspopup="menu"][role="button"]'
  ];
  var TWEET_ARTICLE_SELECTOR = 'article[data-testid="tweet"], article[role="article"]';

  // src/features/post-actions/dom/findMoreButton.ts
  function findMoreButton(article) {
    for (const selector of MORE_BUTTON_SELECTORS) {
      const button = article.querySelector(selector);
      if (button) {
        return button;
      }
    }
    return null;
  }

  // src/shared/async/resolveAfterDelay.ts
  function resolveAfterDelay(milliseconds, resolve) {
    return globalThis.setTimeout(resolve, milliseconds);
  }

  // src/shared/async/sleep.ts
  function sleep(milliseconds) {
    return new Promise(resolveAfterDelay.bind(null, milliseconds));
  }

  // src/shared/dom/waitForElement.ts
  async function waitForElement(selectors, timeoutMs) {
    const expiresAt = Date.now() + timeoutMs;
    while (Date.now() < expiresAt) {
      for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element) {
          return element;
        }
      }
      await sleep(75);
    }
    throw new Error(`Timed out waiting for selectors: ${selectors.join(", ")}`);
  }

  // src/features/post-actions/actions/waitForMenuRoot.ts
  function waitForMenuRoot() {
    return waitForElement(MENU_ROOT_SELECTORS, 2500);
  }

  // src/features/post-actions/actions/openPostMenu.ts
  async function openPostMenu(article) {
    const moreButton = findMoreButton(article);
    if (!moreButton) {
      throw new Error("Post menu trigger not found.");
    }
    moreButton.click();
    return waitForMenuRoot();
  }

  // src/features/post-actions/config/actionDefinitions.ts
  var ACTION_DEFINITIONS = {
    block: {
      confirmKeywords: ["block", "bloquear"],
      keywords: ["block", "bloquear"],
      messageKey: "actionBlock"
    },
    mute: {
      confirmKeywords: [],
      keywords: ["mute", "silenciar"],
      messageKey: "actionMute"
    },
    dismiss: {
      confirmKeywords: [],
      keywords: [
        "not interested",
        "no me interesa",
        "show fewer",
        "mostrar menos",
        "ver menos"
      ],
      messageKey: "actionDismiss"
    }
  };

  // src/shared/text/normalizeText.ts
  function normalizeText(value) {
    return value.normalize("NFD").replace(new RegExp("\\p{Diacritic}", "gu"), "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  // src/features/post-actions/actions/findConfirmationButton.ts
  function findConfirmationButton(action) {
    const { confirmKeywords } = ACTION_DEFINITIONS[action];
    if (confirmKeywords.length === 0) {
      return null;
    }
    for (const selector of CONFIRMATION_BUTTON_SELECTORS) {
      const candidates = Array.from(document.querySelectorAll(selector));
      for (const candidate of candidates) {
        if (candidate.dataset.testid === "confirmationSheetConfirm") {
          return candidate;
        }
        const normalizedLabel = normalizeText(candidate.innerText || candidate.textContent || "");
        for (const keyword of confirmKeywords) {
          if (normalizedLabel.includes(keyword)) {
            return candidate;
          }
        }
      }
    }
    return null;
  }

  // src/features/post-actions/actions/clickConfirmationIfPresent.ts
  async function clickConfirmationIfPresent(action) {
    try {
      await waitForElement(CONFIRMATION_BUTTON_SELECTORS, 900);
    } catch {
      return;
    }
    const confirmationButton = findConfirmationButton(action);
    if (!confirmationButton) {
      return;
    }
    confirmationButton.click();
  }

  // src/_locales/en/messages.json
  var messages_default = {
    extensionName: {
      message: "I Don'T Care About Your Tweets"
    },
    extensionDescription: {
      message: "Adds Block, Mute, and Not Interested buttons to each X.com post."
    },
    actionBlock: {
      message: "Block"
    },
    actionBlockTitle: {
      message: "Block the author of this post"
    },
    actionMute: {
      message: "Mute"
    },
    actionMuteTitle: {
      message: "Mute the author of this post"
    },
    actionDismiss: {
      message: "Not interested"
    },
    actionDismissTitle: {
      message: "Tell X that you are not interested in this post"
    },
    popupPageTitle: {
      message: "I Don't Care About Your Tweets"
    },
    popupHeading: {
      message: "Button kit"
    },
    popupSubtitle: {
      message: "Choose the icon set shown on each post."
    },
    popupReset: {
      message: "Reset"
    },
    popupPreviewAriaLabel: {
      message: "Button kit preview"
    },
    popupKitListAriaLabel: {
      message: "Available button kits"
    },
    kitClassicName: {
      message: "Classic"
    },
    kitClassicDescription: {
      message: "The original button set."
    },
    kitMinimalName: {
      message: "Minimal"
    },
    kitMinimalDescription: {
      message: "Thin, quiet lines for a lighter timeline."
    },
    kitBoldName: {
      message: "Bold"
    },
    kitBoldDescription: {
      message: "Chunkier outlines with stronger visibility."
    },
    kitSharpName: {
      message: "Sharp"
    },
    kitSharpDescription: {
      message: "Angular symbols with a more technical feel."
    },
    kitSoftName: {
      message: "Soft"
    },
    kitSoftDescription: {
      message: "Rounded, friendly shapes with smooth curves."
    },
    dismissFeedbackThankYou: {
      message: "thanks. x will use this to improve your timeline"
    },
    dismissFeedbackUndo: {
      message: "undo"
    },
    popupThemeLight: {
      message: "Day"
    },
    popupThemeDark: {
      message: "Night"
    },
    popupThemeToggleAriaLabel: {
      message: "Toggle popup theme"
    }
  };

  // src/shared/browser/getMessage.ts
  var FALLBACK_MESSAGES = Object.fromEntries(
    Object.entries(messages_default).map(([key, entry]) => [key, entry.message])
  );
  function getMessage(key) {
    try {
      const translated = globalThis.chrome?.i18n?.getMessage(key);
      if (translated) {
        return translated;
      }
    } catch {
      return FALLBACK_MESSAGES[key] ?? key;
    }
    return FALLBACK_MESSAGES[key] ?? key;
  }

  // src/features/post-actions/actions/matchesActionLabel.ts
  function getActionKeywords(action) {
    const { keywords, messageKey } = ACTION_DEFINITIONS[action];
    const localized = normalizeText(getMessage(messageKey));
    return [...keywords, localized];
  }
  function matchesActionLabel(action, label) {
    const normalizedLabel = normalizeText(label);
    for (const keyword of getActionKeywords(action)) {
      if (normalizedLabel.includes(keyword)) {
        return true;
      }
    }
    return false;
  }

  // src/features/post-actions/actions/findActionMenuItem.ts
  function findActionMenuItem(menuRoot, action) {
    const candidates = Array.from(menuRoot.querySelectorAll('button, [role="menuitem"]'));
    for (const candidate of candidates) {
      const label = candidate.innerText || candidate.textContent || "";
      if (matchesActionLabel(action, label)) {
        return candidate;
      }
    }
    return null;
  }

  // src/features/post-actions/dom/setArticleBusyState.ts
  function setArticleBusyState(article, isBusy) {
    const actionBar = article.querySelector(ACTION_BAR_SELECTOR);
    if (!actionBar) {
      return;
    }
    actionBar.dataset.idcaytBusy = String(isBusy);
    const buttons = Array.from(actionBar.querySelectorAll("button"));
    for (const button of buttons) {
      button.disabled = isBusy;
    }
  }

  // src/features/post-actions/actions/runPostAction.ts
  async function runPostAction(article, action) {
    setArticleBusyState(article, true);
    try {
      const menuRoot = await openPostMenu(article);
      const menuItem = findActionMenuItem(menuRoot, action);
      if (!menuItem) {
        throw new Error(`Action item not found: ${action}`);
      }
      menuItem.click();
      await clickConfirmationIfPresent(action);
    } catch (error) {
      console.warn("I Don't Care About Your Tweets action failed.", error);
    } finally {
      setArticleBusyState(article, false);
    }
  }

  // src/features/post-actions/dom/findArticleFromElement.ts
  function findArticleFromElement(target) {
    if (!(target instanceof Element)) {
      return null;
    }
    return target.closest(TWEET_ARTICLE_SELECTOR);
  }

  // src/features/post-actions/events/onBlockButtonClick.ts
  async function onBlockButtonClick(event) {
    event.preventDefault();
    event.stopPropagation();
    const article = findArticleFromElement(event.currentTarget);
    if (!article) {
      return;
    }
    await runPostAction(article, "block");
  }

  // src/features/post-actions/dom/createBlockButton.ts
  function createBlockButton() {
    const button = document.createElement("button");
    const label = getMessage("actionBlockTitle");
    button.type = "button";
    button.className = "idcayt-action-button";
    button.dataset.idcaytAction = "block";
    button.innerHTML = getActionIconMarkup("block");
    button.title = label;
    button.setAttribute("aria-label", label);
    button.addEventListener("click", onBlockButtonClick);
    return button;
  }

  // src/features/post-actions/events/onDismissButtonClick.ts
  async function onDismissButtonClick(event) {
    event.preventDefault();
    event.stopPropagation();
    const article = findArticleFromElement(event.currentTarget);
    if (!article) {
      return;
    }
    await runPostAction(article, "dismiss");
  }

  // src/features/post-actions/dom/createDismissButton.ts
  function createDismissButton() {
    const button = document.createElement("button");
    const label = getMessage("actionDismissTitle");
    button.type = "button";
    button.className = "idcayt-action-button";
    button.dataset.idcaytAction = "dismiss";
    button.innerHTML = getActionIconMarkup("dismiss");
    button.title = label;
    button.setAttribute("aria-label", label);
    button.addEventListener("click", onDismissButtonClick);
    return button;
  }

  // src/features/post-actions/events/onMuteButtonClick.ts
  async function onMuteButtonClick(event) {
    event.preventDefault();
    event.stopPropagation();
    const article = findArticleFromElement(event.currentTarget);
    if (!article) {
      return;
    }
    await runPostAction(article, "mute");
  }

  // src/features/post-actions/dom/createMuteButton.ts
  function createMuteButton() {
    const button = document.createElement("button");
    const label = getMessage("actionMuteTitle");
    button.type = "button";
    button.className = "idcayt-action-button";
    button.dataset.idcaytAction = "mute";
    button.innerHTML = getActionIconMarkup("mute");
    button.title = label;
    button.setAttribute("aria-label", label);
    button.addEventListener("click", onMuteButtonClick);
    return button;
  }

  // src/features/post-actions/dom/createActionBar.ts
  function createActionBar() {
    const actionBar = document.createElement("div");
    actionBar.className = "idcayt-action-bar";
    actionBar.dataset.idcaytBar = "true";
    actionBar.dataset.idcaytBusy = "false";
    actionBar.append(createBlockButton(), createMuteButton(), createDismissButton());
    return actionBar;
  }

  // src/features/post-actions/dom/findActionBarHost.ts
  function findActionBarHost(article) {
    const timestampLink = article.querySelector(ACTION_BAR_HOST_SELECTOR)?.closest("a");
    if (timestampLink) {
      return timestampLink;
    }
    return findMoreButton(article) ?? article.querySelector('[data-testid="User-Name"]');
  }

  // src/features/post-actions/config/dismissFeedbackKeywords.ts
  var DISMISS_FEEDBACK_THANK_YOU_FALLBACKS = [
    "gracias. x usara esto para mejorar tu cronologia",
    "thanks. x will use this to improve your timeline",
    "thanks. x will use this to make your timeline better"
  ];
  var DISMISS_FEEDBACK_UNDO_FALLBACKS = ["deshacer", "undo"];
  function getDismissFeedbackThankYouKeywords() {
    const localized = normalizeText(getMessage("dismissFeedbackThankYou"));
    return [...DISMISS_FEEDBACK_THANK_YOU_FALLBACKS, localized];
  }
  function getDismissFeedbackUndoKeywords() {
    const localized = normalizeText(getMessage("dismissFeedbackUndo"));
    return [...DISMISS_FEEDBACK_UNDO_FALLBACKS, localized];
  }

  // src/features/post-actions/actions/matchesDismissFeedbackCardText.ts
  function matchesDismissFeedbackCardText(text) {
    const normalizedText = normalizeText(text);
    const hasThankYouMessage = getDismissFeedbackThankYouKeywords().some(
      (keyword) => normalizedText.includes(keyword)
    );
    if (!hasThankYouMessage) {
      return false;
    }
    return getDismissFeedbackUndoKeywords().some((keyword) => normalizedText.includes(keyword));
  }

  // src/features/post-actions/dom/isDismissFeedbackCard.ts
  function isDismissFeedbackCard(article) {
    if (article.dataset.testid === "tweet") {
      return false;
    }
    return matchesDismissFeedbackCardText(article.innerText || article.textContent || "");
  }

  // src/features/post-actions/dom/findTweetArticles.ts
  function looksLikeTweetArticle(article) {
    if (isDismissFeedbackCard(article)) {
      return false;
    }
    return article.dataset.testid === "tweet" || article.querySelector(ACTION_BAR_HOST_SELECTOR) !== null || findMoreButton(article) !== null;
  }
  function findTweetArticles() {
    return Array.from(document.querySelectorAll(TWEET_ARTICLE_SELECTOR)).filter(looksLikeTweetArticle);
  }

  // src/features/post-actions/dom/hasActionBar.ts
  function hasActionBar(article) {
    return article.querySelector(ACTION_BAR_SELECTOR) !== null;
  }

  // src/features/post-actions/runtime/ensureActionBars.ts
  function ensureActionBars() {
    const articles = findTweetArticles();
    for (const article of articles) {
      if (hasActionBar(article)) {
        continue;
      }
      const host = findActionBarHost(article);
      if (!host) {
        continue;
      }
      host.insertAdjacentElement("afterend", createActionBar());
    }
  }

  // src/features/post-actions/dom/findDismissFeedbackCards.ts
  function findDismissFeedbackCards() {
    return Array.from(document.querySelectorAll('article[role="article"]'));
  }

  // src/features/post-actions/dom/hideDismissFeedbackCard.ts
  function hideDismissFeedbackCard(article) {
    article.remove();
  }

  // src/features/post-actions/runtime/hideDismissFeedbackCards.ts
  function hideDismissFeedbackCards() {
    const articles = findDismissFeedbackCards();
    for (const article of articles) {
      if (!isDismissFeedbackCard(article)) {
        continue;
      }
      hideDismissFeedbackCard(article);
    }
  }

  // src/features/post-actions/runtime/onTimelineMutations.ts
  function onTimelineMutations(mutations) {
    if (mutations.length === 0) {
      return;
    }
    hideDismissFeedbackCards();
    ensureActionBars();
  }

  // src/features/post-actions/runtime/observeTimeline.ts
  function observeTimeline() {
    const observer = new MutationObserver(onTimelineMutations);
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    return observer;
  }

  // src/features/post-actions/runtime/startPostActionExtension.ts
  var hasStarted = false;
  function startPostActionExtension() {
    if (hasStarted) {
      return;
    }
    hasStarted = true;
    initializeButtonKitPreference();
    hideDismissFeedbackCards();
    ensureActionBars();
    observeTimeline();
  }

  // src/content/index.ts
  startPostActionExtension();
})();
